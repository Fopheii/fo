<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <title>Downloaderi - Calculate Download time/speed</title>
    <link rel="icon" type="image/ico" href="favicon.ico" />
    <meta name="Description" content="Download time calculator helps you to calculate the download time it takes to download a file based on your internet download speed/bandwidth.
Calculate download time" />
    <meta name="Keywords" content="download,time,calculate, Estimate,bandwidth,broadband,downloadspeed,speed,upload,upload time calculator">
    <meta property="og:title" content="Download Time Calculator - Calculate Download time" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="http://downloadtimecalculator.com/" />
    <meta property="og:image" content="http://downloadtimecalculator.com/Download-Time-Calculator.png" />

    <link rel="stylesheet" href="calstyles.css?v=2">
    <link rel="icon" type="image/png" href="../img/logo.png"/>

    <!-- google fonts  -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alumni+Sans+Pinstripe&family=Archivo+Black&family=Dancing+Script:wght@700&family=Great+Vibes&family=Russo+One&display=swap" rel="stylesheet">

    <!-- font awesome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- w3 css  -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="script.js"></script>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script src="lazyad-loader.min.js" async></script>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-7628396955293796",
            enable_page_level_ads: true
        });
    </script>
    <!-- link bootstrap  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css">
<style>.active4{color: white;}</style>
</head>

<body>
    <!-- Navbar  -->
    <?php include('navbar.php') ?>
    <!-- MAIN BODY  -->


    <div class="text-center mt-5 w3-animate-zoom">
        <h1><span class="">File Transfer Calculator</span></h1>
        <h4><span class="">How much time would it take to transfer a file?</span></h4>
    </div>


    <div class="desktopcenter ebbg_color">
        <div class="content">

            <form onsubmit="return false">
                <!-- card 1 -->
                <div id="speed" class="p-4 rounded card">
                    <h3>How fast is your data internet speed?</h3>
                    <h4>File Transfer Speed</h4>
                    <p>
                        <label for="internetSpeed"></label>
                        <input id="internetSpeed_p" type="button" value="+" onclick="internetSpeed.value = (parseInt(internetSpeed.value)+1).toFixed(2)">
                        <input id="internetSpeed" type="number" min="0" step="0.01" value="10" placeholder="Download speed" autofocus>


                        <input id="internetSpeed_p" type="button" value="-" onclick="internetSpeed.value = (parseInt(internetSpeed.value)-1).toFixed(2)">

                        <select id="internetSpeedBase" aria-label="Unit of speed like Kbps, Mbps, Gbps">
                            <option value="10^3">Kbps</option>
                            <option value="10^6" selected>Mbps</option>
                            <option value="10^9">Gbps</option>

                        </select>
                    </p>

                    <p class="idkSpeed"><a id="speedtestLink" href="http://speedtest.net" rel="nofollow" target="_blank">I don't know my internet speed</a></p>

                    <div>
                        <label class="collapse-head" for="_1">?</label>
                        <input id="_1" type="checkbox">
                        <div>
                            <p class="overhead-p"><label for="internetOverhead">Overhead</label>
                                <select style="font-size: 1rem;" id="internetOverhead">
                                    <option value="1" selected>None</option>
                                    <option value="0.99">1%</option>
                                    <option value="0.95">5%</option>
                                    <option value="0.9">10% (Typical TCP overhead)</option>
                                    <option value="0.85">15%</option>
                                    <option value="0.8">20%</option>
                                    <option value="0.75">25%</option>
                                    <option value="0.7">30%</option>
                                    <option value="0.6">40%</option>
                                    <option value="0.5">50%</option>
                                    <option value="0.4">60%</option>
                                    <option value="0.3">70%</option>
                                    <option value="0.2">80%</option>
                                    <option value="0.1">90%</option>
                                    <option value="0.05">95%</option>
                                    <option value="0.01">99%</option>
                                </select>

                            </p>
                        </div>
                    </div>
                </div>

                <!-- card 2 -->
                <div class="p-4 rounded card " id="file">
                    <h3>What is the size of the file you want to transfer?</h3>
                    <h4>File size</h4>
                    <p>
                        <label for="fileSize"></label>
                        <input id="internetSpeed_p" type="button" value="+" onclick="fileSize.value = (parseInt(fileSize.value)+1).toFixed(2)">

                        <input type="number" id="fileSize" value="1" step="0.01" min="0">

                        <input id="internetSpeed_p" type="button" aria-label="Data unit like KB, MB, GB" value="-" onclick="fileSize.value = (parseInt(fileSize.value)-1).toFixed(2)">
                        <select id="fileSizeBase">
                            <option value="2^10">KB </option>
                            <option value="2^20">MB </option>
                            <option value="2^30" selected>GB </option>
                            <option value="2^40">TB </option>
                        </select>
                    </p>

                    <p>
                        <button style="margin: 0 auto;" class="cal-button" id="calculateButton">Calculate</button>
                    </p>
                </div>

            </form>

            <!-- card 3 result -->
            <div class="p-4 rounded card " id="results" style="background-color: #dce9ff;">

                <div id="results_inner">
                    <p class="">It would take</p>
                    <p style="color:green" class="time">0</p>
                    <p class="">to transfer <span class="size"></span> </p>
                    <p class="">at <span class="speed"></span>/sec</p>
                </div>

                <div class="didyouknow"> <a href="./doyouknow" target="_blank">Did you know that there is a HUGE difference between Mbps and MBps?</a></div>
                <hr>



            </div>

        </div>

    </div>

    <div class="info ebbg_color">
        <!-- card  -->
        <div class="content">
            <div class="card p-4 rounded" style="background-color: #dce9ff;">
                <h2>What is File Transfer Calculator?</h2>
                <p>File Transfer Calculator is used to calculate the time required to File Transfer any file based on your transfer speed without actually transferring any file. It is useful if you have large amount of data to transfer especially if you intend to send big files over long distances.</p>
                <h3>How to use?</h3>
                <p> 1. Enter your transfer speed.<br>
                    2. Enter the size of the data.<br>
                    3. This tool will calculate the time it would take to transfer file.
                <p>
            </div>
        </div>
    </div>

    <div>
        <!-- footer  -->
        <?php include('footer.php'); ?>

        <!-- footer end  -->

    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

</html>