<footer class="py-3 footer-1 text-white mt-auto pt-5 pb-5 footer_styling" id="downloadfooter">
    <div class="container-fluid">
    <div class="container p-0">

<!-- Row 1 -->
        <div class="row">
        <div class="col-md-12">
                <div class="row">
        <div class="pb-3 col-md-3 col-6"><a href="https://weeksinyear.com" class="nav-link px-2 text-white footer_nav_links">Time Converter</a></div>
        <div class="pb-3 col-md-3 col-6"><a href="privacy-policy.php" class="nav-link px-2 text-white footer_nav_links">Policy</a></div>
        <div class="pb-3 col-md-3 col-6"><a href="terms-and-conditions.php" class="nav-link px-2 text-white footer_nav_links">Terms of use</a></div>
        <div class="pb-3 col-md-3 col-6"><a href="contact.php" class="nav-link px-2 text-white footer_nav_links">Contact us</a></div>
                </div>
        </div>
        </div>

            <hr class="text-white">
            <div class="footer-line-text">
                <p class="text-center text-white"><i class="fa fa-bolt text-white"></i> Weeks in a Year</p>
            </div>

    </div>
    </div>
</footer>