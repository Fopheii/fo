<!-- material icons  -->
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<!-- navbar start  -->
<nav class="navbar navbar-expand-lg navbar-dark navbar_bg ">
  <div class="container">
    <a class="navbar-brand logo" href="https://weeksinyear.com">

    <h2 class="text-white brand-text">Time Converter</h2></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active1" aria-current="page" href="https://weeksinyear.com">Download Time</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active2" href="dataTransfer">Data Transfer</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active3" href="bandwidth">Bandwidth</a>
        </li>
      <li class="nav-item">
          <a class="nav-link active4" href="fileTransfer">File Transfer</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active5" href="uploadTime">Upload Time</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active6" href="timeconvertor">Time Convertor</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- navbar end  -->